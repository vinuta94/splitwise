<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book_model extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


public function get_all_books($kd)
{
$this->db->from('circle');
$this->db->where('created_by',$kd);
$query=$this->db->get();
return $query->result();
}

public function get_all_user()
{
$this->db->from('register');
$query=$this->db->get();
return $query->result();
}

public function get_split_users()
{
	$this->db->from('register');
	$query=$this->db->get();
	return $query->result();
}
public function get_expense()
{
	$this->db->from('expense');

	$query=$this->db->get();
	return $query->result();
}

	public function get_by_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('gid',$id);
		$query = $this->db->get();

		return $query->row();
	}


	public function get_user_id($id)
	{
		$this->db->from($this->table);
		$this->db->where('id',$id);
		$query = $this->db->get();

		return $query->row();
	}

	public function book_add($data)
	{
		$this->db->from('register');
		$this->db->insert($this->table, $data);
		return $this->db->insert_id();
	}

	public function get_group_members()
{
  $this->db->from('circle');
	//$this->db->where('gid',$id);
  $query=$this->db->get();
	//$data['members']=$query->result_array();
	//$data['count']=$query->num_rows();
	//$data['pages']=ceil($data['count']/3);
  return $query->result();

}



	public function insertmydata($data)
	{
	    $this->db->insert('circle', $data);
	}

	public function addexpense($data)
	{
		 $var=$data.balance;
		 $this->db->insert('expense', $data);
	}

	public function book_update($where, $data)
	{
		$this->db->update($this->table, $data, $where);
		return $this->db->affected_rows();
	}

	public function delete_by_id($id)
	{

		$this->db->where('exp_id', $id);
		$this->db->delete($this->table);
	}

}
