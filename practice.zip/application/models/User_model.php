<?php
class User_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

	function get_user($email, $password)
	{
		$this->db->where('email', $email);
		$this->db->where('pass', ($password));
        $query = $this->db->get('register');
		return $query->result();
	}

	// get user
	function get_user_by_id($id)
	{
		$this->db->where('id', $id);
        $query = $this->db->get('register');
		return $query->result();
	}

    //insert into user table
    public function insert($data) {
         if ($this->db->insert("register", $data)) {
            return true;
         }
      }

      public function get_group()
    {
      $this->db->from('circle');
      $query=$this->db->get();
      return $query->result();

    }
}
?>
