<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link href='http://fonts.googleapis.com/css?family=Marcellus' rel='stylesheet' type='text/css'>
<link href="http://localhost/CodeIgniter/css/styles.css" rel="stylesheet" type="text/css">

<style>



#container{

width:960px;
height:610px;
margin:50px auto
}
#fugo{
float:right
}
form{
width:320px;
padding:0 50px 20px;

border:1px solid #ccc;
box-shadow:0 0 5px;
font-family:'Marcellus',serif;
float:left;
margin-top:10px
}
h1{
text-align:center;
font-size:28px
}
hr{
border:0;
border-bottom:1.5px solid #ccc;
margin-top:-10px;
margin-bottom:30px
}
label{
font-size:17px
}
input{
width:100%;
padding:10px;
margin:6px 0 20px;
border:none;
box-shadow:0 0 5px
}
input#submit{
margin-top:20px;
font-size:18px;
background:linear-gradient(#22abe9 5%,#36caf0 100%);
border:1px solid #0F799E;
color:#fff;
font-weight:700;
cursor:pointer;
text-shadow:0 1px 0 #13506D
}
input#submit:hover{
background:linear-gradient(#36caf0 5%,#22abe9 100%)
}
p{
	color:red;
}


	</style>
</head>
<body>
	<div id="container">

<form action="<?php echo base_url().'index.php/Login'?>" method="post">
<h1>Login</h1>


Email :
	<input type="text" name="email" value="<?php echo set_value('email'); ?>">
	<?php echo form_error('email'); ?>

Password :
	<input type="password" name="pass" value="<?php echo set_value('pass'); ?>">
<?php echo form_error('pass'); ?>

<input type="submit" value="Login">

	New User? <a href="<?php echo base_url(); ?>index.php/Signup">Sign Up Here</a>

	</form>

</div>

</body>
</html>
