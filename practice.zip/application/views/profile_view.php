<!DOCTYPE html>
<html>
<head>

	<title>Home Page | KodingMadeSimple.com</title>
	<!--link the bootstrap css file-->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <nav class="navbar navbar-default" role="navigation">
  	<div class="container-fluid">
  		<div class="navbar-header">
  			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar1">
  				<span class="sr-only">Toggle navigation</span>
  				<span class="icon-bar"></span>
  				<span class="icon-bar"></span>
  				<span class="icon-bar"></span>
  			</button>
  			<a class="navbar-brand" href="#">Profile</a>
  		</div>
  		<div class="collapse navbar-collapse" id="navbar1">
  			<ul class="nav navbar-nav navbar-right">
  				<?php if ($this->session->userdata('login')){ ?>
  				<li><p class="navbar-text">Hello <?php echo $this->session->userdata('uname'); ?></p></li>
  				<li><a href="<?php echo base_url(); ?>index.php/Signup/logout">Log Out</a></li>
  				<?php } else { ?>
  				<li><a href="<?php echo base_url(); ?>index.php/Signup/login">Login</a></li>
  				<li><a href="<?php echo base_url(); ?>index.php/Signup">Signup</a></li>
  				<?php } ?>
  			</ul>
  		</div>
  	</div>
  </nav>


<div class="container">
	<div class="row">
		<div class="col-md-4">
      Hello <?php echo $this->session->userdata('uname'); ?>
			<h4>Notification </h4>
			<p>Logged in as <?php echo $this->session->userdata('uname'); ?></p>

		</div>
		<div class="col-md-8">
			<h2>Welcome!!!</h2>
			<p><?php echo $this->session->userdata('email'); ?></p>
		</div>
	</div>
</div>
<script type="text/javascript" src="<?php echo base_url("assets/js/jquery-1.10.2.js"); ?>"></script>
<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
</body>
</html>
