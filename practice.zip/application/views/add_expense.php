<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Splitwise</title>
    <link href="<?php echo base_url('assests/bootstrap/css/bootstrap.min.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assests/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

<body>

  <div class="bs-example">
      <nav role="navigation" class="navbar navbar-default">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
              <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
              </button>
              <a href="#" class="navbar-brand">Splitwise</a>
          </div>
          <!-- Collection of nav links and other content for toggling -->
          <div id="navbarCollapse" class="collapse navbar-collapse">

              <ul class="nav navbar-nav navbar-right">

                  <li><a href="<?php echo base_url().'index.php/Home_controller/logout'?>">Logout</a></li>

              </ul>
          </div>
      </nav>

    <div class="modal-header">

  <center>    <h3 class="modal-title">Add Expense</h3> </center>
    </div>
    <div class="modal-body form">
      <form action="<?php echo base_url().'index.php/Book/addexpense'?>" method="post" id="form" class="form-horizontal">


        <input type="hidden" value="" name="gid"/>
        <div class="form-body">
          <div class="form-group">
            <label class="control-label col-md-3">Description</label>
            <div class="col-md-9">
              <input name="description" placeholder="Description" class="form-control" type="text">
            </div>
          </div>

          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Paid By</label>
            <div class="col-md-9">

              <select id="paidby"  name="paidby">
                 <?php foreach($employee as $emp){
                  
                   ?>
                  <option value= "<?php echo $emp->members; ?>" > <?php echo $emp->members; ?></option>
               <?php } ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3">Split</label>
            <div class="col-md-9">
              <div class="row margin">

          <select id="split" multiple="multiple" name="split[]">
             <?php foreach($employee as $emp){?>

                <option value="<?php echo $emp->members; ?>" > <?php echo $emp->members; ?></option>
           <?php } ?>
          </select>
 </div>

            </div>
          </div>

        </div>

        </div>
        <div class="modal-footer">
          <button type="submit" id="btnSave"  class="btn btn-primary">Add</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
        </div>
  </form>
  <a href="<?php echo base_url().'index.php/expense'?>"<i class=""></i>Next</a>

<!-- End Bootstrap modal -->

</body>
</html>
