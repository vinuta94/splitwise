<!DOCTYPE html>
<html>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<style>
#container{
width:960px;
height:610px;
margin:50px auto
}
#fugo{
float:right
}
form{
width:320px;
padding:0 50px 20px;

border:1px solid #ccc;
box-shadow:0 0 5px;
font-family:'Marcellus',serif;
float:left;
margin-top:10px
}
h1{
text-align:center;
font-size:28px
}
hr{
border:0;
border-bottom:1.5px solid #ccc;
margin-top:-10px;
margin-bottom:30px
}
label{
font-size:17px
}
input{
width:100%;
padding:10px;
margin:6px 0 20px;
border:none;
box-shadow:0 0 5px
}
input#submit{
margin-top:20px;
font-size:18px;
background:linear-gradient(#22abe9 5%,#36caf0 100%);
border:1px solid #0F799E;
color:#fff;
font-weight:700;
cursor:pointer;
text-shadow:0 1px 0 #13506D
}
input#submit:hover{
background:linear-gradient(#36caf0 5%,#22abe9 100%)
}

	</style>

<body>
  <div class="bs-example">
      <nav role="navigation" class="navbar navbar-default">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
              <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
              </button>
              <a href="#" class="navbar-brand">Splitwise</a>
          </div>
          <!-- Collection of nav links and other content for toggling -->
          <div id="navbarCollapse" class="collapse navbar-collapse">

              <ul class="nav navbar-nav navbar-right">
								<li><a href="<?php echo base_url().'index.php/Book'?>">View Group</a></li>
                  <li><a href="<?php echo base_url().'index.php/Home_controller/logout'?>">Logout</a></li>

              </ul>
          </div>
      </nav>

  <div id="container">
<h3> Create Group </h3>
<form action="<?php echo base_url().'index.php/Group_controller/insertmydata'?>" method="post">
<label for="attendies">Group Name</label>
<input type="text" name="gname" placeholder="name"><br>

        <label for="attendies">Members</label>
        <select id="attendies" multiple="multiple" name="attendies[]">
           <?php foreach($employee as $emp){?>
            <option value="<?php echo $emp->fname; ?>" > <?php echo $emp->fname; ?></option>
         <?php } ?>
        </select>
				<input type="text" name="balance" placeholder="balance"><br>

<input type="submit" value="Create">
</form>
</div>

</body>
</html>
