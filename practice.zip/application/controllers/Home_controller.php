<?php
class Home_controller extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('html'));
		$this->load->library('session');
	}

	function index()
	{
		$this->load->view('home_view');
	}

	function logout()
	{
		// destroy session
        $data = array('login' => '', 'uname' => '', 'uid' => '');
        $this->session->unset_userdata($data);
        $this->session->sess_destroy();
		redirect('index.php/Home_controller');
	}
}
