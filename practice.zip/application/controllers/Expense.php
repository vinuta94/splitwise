<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Expense extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Expense_model');
	 	}


	public function index()
	{

		$data['books']=$this-> Expense_model->get_all_expense();
		$this->load->view('expense',$data);
	}


	public function book_add()
		{
			$data = array(
				'description' => $this->input->post('description'),
				'amt' => $this->input->post('amt'),
				'paidby' => $this->input->post('paidby'),
				'split_to' => $this->input->post('split_to'),
				);
			$insert = $this->expense_model->book_add($data);
			echo json_encode(array("status" => TRUE));
		}
		public function ajax_edit($id)
		{
			$data = $this->expense_model->get_by_id($id);



			echo json_encode($data);
		}

		public function book_update()
	{
		$data = array(
			'description' => $this->input->post('description'),
			'amt' => $this->input->post('amt'),
			'paidby' => $this->input->post('paidby'),
			'split_to' => $this->input->post('split_to'),
			);
		$this->book_model->book_update(array('book_id' => $this->input->post('book_id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function book_delete($id)
	{
		$this-> Expense_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
