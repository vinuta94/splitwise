<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('Member');
	 	}


	public function index()
	{

		$data['books']=$this->Member->get_all_books();
		$this->load->view('user',$data);
	}

	public function group() {
		$data['books']=$this->User_model->get_group();
		 $this->load->view('group_view',$data);
	}


	public function book_add()
		{
			$data = array(
				'id' => $this->input->post('id'),
				'fname' => $this->input->post('fname'),
				'lname' => $this->input->post('lname'),
				'email' => $this->input->post('email'),
				'role' => $this->input->post('role'),
				);
			$insert = $this->Member->book_add($data);
			echo json_encode(array("status" => TRUE));
		}
		public function ajax_edit($id)
		{
			$data = $this->Member->get_by_id($id);



			echo json_encode($data);
		}

		public function book_update()
	{
		$data = array(
			'id' => $this->input->post('id'),
			'fname' => $this->input->post('fname'),
			'lname' => $this->input->post('lname'),
			'email' => $this->input->post('email'),
			'role' => $this->input->post('role'),
			);
		$this->Member->book_update(array('id' => $this->input->post('id')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function book_delete($id)
	{
		$this->Member->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
