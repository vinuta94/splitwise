<?php
   class Group_controller extends CI_Controller {

      function __construct() {
         parent::__construct();
         $this->load->helper('url');
         $this->load->database();
         $this->load->library(array('session'));
         $this->load->model('Book_model');

      }

      public function expense()
      {
        $data['employee']=$this->Book_model->get_expense();
         $this->load->view('add_expense',$data);
      }

      public function index() {
        $data['employee']=$this->Book_model->get_split_users();
         $this->load->view('group',$data);
      }

      public function insertmydata()
      {
        /*$insData = $this->input->post('attendies');
        $columns = implode(", ",array_keys($insData));
        $escaped_values = array_map('mysql_real_escape_string', array_values($insData));
        $values  = implode("_", $escaped_values);*/
        $array = $this->input->post('attendies');
        $comma_separated = implode(",", $array);
        //$serialized_array = serialize($array);
        //$unserialized_array = unserialize($serialized_array);

        //$values=var_dump($serialized_array); // gives back a string, perfectly for db saving!
        //var_dump($unserialized_array);
      //  $createduser=$this->session->userdata['id']['uid'];
      

        $createdby  =   $this->session->userdata('uid');

        $data = array(
            'gname' => $this->input->post('gname'),
            'members' => $comma_separated,
            'balance' => $this->input->post('balance'),
            'created_by' => $createdby

        );
       $ins=$this->Book_model->insertmydata($data);
        $this->session->set_userdata($data);
        if (!$ins)
        {

            redirect('index.php/book');
        }
        else
        {
            // error
          //  $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  Please try again later!!!</div>');
            redirect('index.php/Group_controller/');
        }
      }

   }
?>
