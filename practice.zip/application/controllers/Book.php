<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book extends CI_Controller {


	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->model('book_model');
	 	}


	public function index()
	{
		  $createdby  =   $this->session->userdata('uid');
		$data['books']=$this->book_model->get_all_books($createdby);
		$this->load->view('book_view',$data);
	}

	public function add_expense()
{
	 $createdby  =   $this->session->userdata('uid');

   $data['employee']=$this->book_model->get_group_members();

  $this->load->view('add_expense',$data);
}

public function addexpense()
{
	/*$insData = $this->input->post('attendies');
	$columns = implode(", ",array_keys($insData));
	$escaped_values = array_map('mysql_real_escape_string', array_values($insData));
	$values  = implode("_", $escaped_values);*/
	$array = $this->input->post('split');
	$comma_separated = implode(",", $array);
	//$serialized_array = serialize($array);
	//$unserialized_array = unserialize($serialized_array);


	$createdby  =   $this->session->userdata('uid');
	$balance  =   $this->session->userdata('balance');

	$data = array(
			'description' => $this->input->post('description'),
			'id' => $createdby,
			'amt' => $balance,
			'paidby' => $this->input->post('paidby'),
			'split' => $comma_separated
		);
 $ins=$this->book_model->addexpense($data);
	$this->session->set_userdata($data);
	if (!$ins)
	{

			redirect('index.php/expense');
	}
	else
	{
			// error
		//  $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  Please try again later!!!</div>');
			redirect('index.php/Group_controller/');
	}
}




	public function add_group()
		{
			$data = array(
					'gid' => $this->input->post('gid'),
					'gname' => $this->input->post('gname'),
					'members' => $this->input->post('members'),

				);


			$insert = $this->book_model->book_add($data);
			echo json_encode(array("status" => TRUE));
		}


		public function add_user()
			{
				$data = array(
						'id' => $this->input->post('id'),
						'fname' => $this->input->post('fname'),
						'lname' => $this->input->post('lname'),
						'email' => $this->input->post('email'),
						'role' => $this->input->post('role'),
					);
				$insert = $this->book_model->book_add($data);
				echo json_encode(array("status" => TRUE));
			}

		public function add_exp()
			{
				$data = array(
						'description' => $this->input->post('description'),
						'amt' => $this->input->post('amt'),
						'paidby' => $this->input->post('paidby'),
						'split_to' => $this->input->post('split_to'),
					);
				$insert = $this->book_model->add_exp($data);
				echo json_encode(array("status" => TRUE));
			}


		public function ajax_edit($id)
		{
			$data = $this->book_model->get_user_id($id);
			echo json_encode($data);
		}

		public function book_update()
	{
		$data = array(
				'gid' => $this->input->post('gid'),
				'gname' => $this->input->post('gname'),
				'members' => $this->input->post('members'),
				'balance' => $this->input->post('balance'),
			);
		$this->book_model->book_update(array('gid' => $this->input->post('gid')), $data);
		echo json_encode(array("status" => TRUE));
	}

	public function book_delete($id)
	{
		$this->book_model->delete_by_id($id);
		echo json_encode(array("status" => TRUE));
	}



}
